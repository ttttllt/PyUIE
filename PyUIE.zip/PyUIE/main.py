import argparse
import os
import numpy as np
import torch
from PIL import Image
from ignite.metrics import SSIM, PSNR
from path import Path
from torch.utils.data import Dataset
from dataset import RawAndReferenceWithNameDataset
from utils import ImageUtils
from PyramidNet import LPTN

def run_model(model, dataloader, device):
    model.eval()
    model.to(device)
    with torch.no_grad():
        for x, y, name in dataloader:
            x = x.to(device)
            y = y.to(device)
            fake_B_low, fake_B_full,restored_images = model(x)
            yield x, fake_B_full, y, name


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, help="model_path")
    parser.add_argument("--initmodel", type=str, help="initmodel_path")
    parser.add_argument("-x", type=str, help="input_path")
    parser.add_argument("-y", type=str, help="reference_path")
    parser.add_argument("-o", "--output", type=str, help="output_path")

    args = parser.parse_args()

    if not os.path.exists(args.output):
        os.makedirs(args.output)

    device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")
    dataset = RawAndReferenceWithNameDataset(args.x, args.y)
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=1, shuffle=False)

    model = LPTN()
    model.load_state_dict(torch.load(args.model, map_location=device), strict=False)

    print("Started, please wait...")

    ssim = SSIM(data_range=1.0)
    psnr = PSNR(data_range=1.0)

    ssim_with_img_names = []
    psnr_with_img_names = []

    for xs, y_preds, ys, names in run_model(model, dataloader, device):
        y_preds = y_preds.cpu()
        ys = ys.cpu()

        for x, y_pred, y, name in zip(xs, y_preds, ys, names):
            ssim.update((y_pred.unsqueeze(0), y.unsqueeze(0)))
            s = ssim.compute()
            ssim.reset()

            psnr.update((y_pred.unsqueeze(0), y.unsqueeze(0)))
            p = psnr.compute()
            psnr.reset()

            ssim_with_img_names.append((s, name))
            psnr_with_img_names.append((p, name))

            ImageUtils.save_image(y_pred, os.path.join(args.output, name))

    psnr_with_img_names.sort()
    for i, (s, name) in enumerate(psnr_with_img_names):
        x = Image.open(os.path.join(args.x, name)).convert("RGB")
        y_pred = Image.open(os.path.join(args.output, name)).convert("RGB")
        y = Image.open(os.path.join(args.y, name)).convert("RGB")

        assert x.size == y_pred.size == y.size

        stacked_img = np.hstack((np.array(x), np.array(y_pred), np.array(y)))
        stacked_img = Image.fromarray(stacked_img)

        sorted_path = Path(args.output) / "sorted"
        if not sorted_path.exists():
            sorted_path.makedirs_p()
        stacked_img.save(sorted_path / f"{i:03d}_psnr={s:.4f}_{name}.png")